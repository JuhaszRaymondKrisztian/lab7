var button = document.getElementById("button");
var nume = document.querySelector("h1");
var prenume = document.querySelector("h2");
var img = document.getElementById("image-container");
var asteptari = document.querySelector("h4");
var body = document.body;

var originalContent = 
{
  nume: "Nume: Juhasz",
  asteptari: "Discipline: <a href='https://etti.utcluj.ro/planuri-de-invatamant.html'>https://etti.utcluj.ro/planuri-de-invatamant.html</a>",
  imgSrc: "poze/Picture1.jpg",
  background: "background1.png",
  fontColor: "#000"
};

var updatedContent = 
{
  nume: "Functie: Senior Java Dev",
  asteptari: "Experiente: <ol><li>internship</li><li>travel</li></ol>",
  imgSrc: "Poze/reimu.png",
  background: "Poze/background2.png",
  fontColor: "#000"
};

var isOriginalState = true;
var originalBackground = body.style.background;

function toggleContent() 
{
  if (isOriginalState) 
  {
    nume.innerHTML = updatedContent.nume;
    asteptari.innerHTML = updatedContent.asteptari;
    img.innerHTML = '<img src="' + updatedContent.imgSrc + '" alt="New Poza">';
    body.style.background = 'url("' + updatedContent.background + '")';
    body.style.color = updatedContent.fontColor;
  } else 
  {
    nume.innerHTML = originalContent.nume;
    asteptari.innerHTML = originalContent.asteptari;
    img.innerHTML = '<img src="' + originalContent.imgSrc + '" alt="Poza">';
    body.style.background = originalBackground;
    body.style.color = originalContent.fontColor;
  }

  isOriginalState = !isOriginalState;

  document.getElementById("nume").classList.toggle("changeNameClass");

}

var birthYearElement = document.getElementById("birth-year");

birthYearElement.addEventListener("mouseover", showAge);
birthYearElement.addEventListener("mouseout", hideAge);

function showAge() {
  var birthYear = parseInt(birthYearElement.getAttribute("data-year"), 10);

  var currentYear = new Date().getFullYear();
  var age = currentYear - birthYear;

  birthYearElement.innerHTML = "Varsta: " + age;
}

function hideAge() {
  birthYearElement.innerHTML = "Anul de nastere: " + birthYearElement.getAttribute("data-year");
}

var slideIndex = 0;

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("slide");

  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  slideIndex++;

  if (slideIndex > slides.length) {
    slideIndex = 1;
  }

  slides[slideIndex - 1].style.display = "block";

  setTimeout(showSlides, 3000);
}

function plusSlides(n) {
  slideIndex += n;
  showSlides();
}

document.addEventListener("DOMContentLoaded", function () {
  showSlides();
});


button.addEventListener("click", toggleContent);